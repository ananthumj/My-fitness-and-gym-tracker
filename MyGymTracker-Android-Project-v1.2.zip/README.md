# My Gym Tracker (Android)

A private, offline-first Android gym and fitness tracker. No login, ads, subscription, or internet permission.

## Included
- Workout log with date, muscle group, exercise, sets, reps, weight (kg), and cardio duration
- Five editable-by-selection workout categories: Back & Biceps; Chest & Triceps; Shoulder & Traps; Legs + Core; Cardio & Abs
- Previous best weight lookup for an exercise
- Food diary with calories and protein, plus today's totals
- Body weight and waist measurement history
- Dark/light theme toggle
- JSON backup export and restore using Android's document picker
- Local SQLite storage

## Build the APK for free
1. Create a free GitHub account if you do not already have one.
2. Create a new repository, e.g. `my-gym-tracker`.
3. Upload all files and folders from this project to the repository root.
4. Open **Actions** in the repository. Allow workflows if GitHub asks.
5. Run **Build Android APK** using **Run workflow**, or push to `main`.
6. Open the completed workflow run and download the `MyGymTracker-debug-apk` artifact.
7. Extract the downloaded ZIP. Install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

## Build locally (optional)
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Data and privacy
All records are stored in the app's private local database. The app requests no internet permission. Export backups regularly; uninstalling the app or clearing its storage can erase local data. Restore currently appends backup entries, so avoid importing the same backup more than once.

## Notes
This is a starter personal-use app. Review and test the APK on your phone before relying on it as your sole fitness record. The debug APK is not Play Store signed for public distribution.


Version 1.2: custom black-and-white dumbbell/ECG launcher icon based on the supplied reference image. App ID remains unchanged for in-place upgrades.
