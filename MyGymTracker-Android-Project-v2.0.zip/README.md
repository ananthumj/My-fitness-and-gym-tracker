# My Gym Tracker 2.0

Offline-first Android fitness tracker built with Kotlin, Jetpack Compose, and SQLite.

## What's new in 2.0
- Session-based workout logging: one session contains multiple exercises.
- Individual editable sets for each exercise, each with reps, weight (kg), and optional cardio minutes.
- Add/remove sets and exercises before saving.
- Reopen completed sessions to edit date, group, notes, exercises, and sets; delete sessions.
- Five colour-coded muscle groups.
- Exercise library with search and custom exercise names.
- Previous-session performance and personal-best weight lookup.
- Workout calendar with date filtering.
- Exercise progression chart and training statistics.
- Nutrition log, daily calorie/protein totals, body weight/waist history.
- Dark/light theme, manual JSON backup/restore, custom launcher icon.

## Existing data
The application ID remains `com.anandu.mygymtracker`. The SQLite database version is upgraded from v1 to v2. On an ordinary in-place app update, existing flat workout rows are migrated into sessions, one legacy row per session, with the previous set count expanded into individual sets. Meals and body measurements remain in their existing tables.

Before installing, export a JSON backup from the old app. If Android reports a signature mismatch, uninstall the old app only after backup, install the new APK, then restore the JSON backup. Do not clear app storage as part of an ordinary update.

## Build
Use JDK 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow expects `MyGymTracker-Android-Project-v2.0.zip` at the repository root and extracts it into `source/` before building.

## Privacy
No INTERNET permission is declared. Records are stored locally in the app's private SQLite database. Export backups to a location you control and keep them private. This is a personal-use app; test it and retain backups before relying on it as your only record.
