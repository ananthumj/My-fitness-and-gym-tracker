package com.anandu.mygymtracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val groups = listOf("Back & Biceps", "Chest & Triceps", "Shoulder & Traps", "Legs + Core", "Cardio & Abs")
private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

class GymDb(ctx: Context) : SQLiteOpenHelper(ctx, "gym_tracker.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE workouts(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, muscle TEXT, exercise TEXT, sets INTEGER, reps INTEGER, kg REAL, duration INTEGER)")
        db.execSQL("CREATE TABLE meals(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, food TEXT, calories INTEGER, protein REAL)")
        db.execSQL("CREATE TABLE body(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, weight REAL, waist REAL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addWorkout(date:String, muscle:String, exercise:String, sets:Int, reps:Int, kg:Double, duration:Int) {
        val v=ContentValues().apply { put("date",date); put("muscle",muscle); put("exercise",exercise); put("sets",sets); put("reps",reps); put("kg",kg); put("duration",duration) }
        writableDatabase.insert("workouts",null,v)
    }
    fun addMeal(date:String, food:String, calories:Int, protein:Double) {
        val v=ContentValues().apply { put("date",date); put("food",food); put("calories",calories); put("protein",protein) }
        writableDatabase.insert("meals",null,v)
    }
    fun addBody(date:String, weight:Double, waist:Double) {
        val v=ContentValues().apply { put("date",date); put("weight",weight); put("waist",waist) }
        writableDatabase.insert("body",null,v)
    }
    fun rows(table:String): List<Map<String,String>> {
        val out=mutableListOf<Map<String,String>>()
        readableDatabase.rawQuery("SELECT * FROM $table ORDER BY date DESC, id DESC",null).use { c ->
            while(c.moveToNext()) {
                val m=mutableMapOf<String,String>()
                for(i in 0 until c.columnCount) m[c.getColumnName(i)] = c.getString(i) ?: ""
                out.add(m)
            }
        }
        return out
    }
    fun best(exercise:String): String {
        readableDatabase.rawQuery("SELECT MAX(kg) FROM workouts WHERE lower(exercise)=lower(?)", arrayOf(exercise)).use {
            return if(it.moveToFirst() && !it.isNull(0)) it.getDouble(0).toString() else "—"
        }
    }
    fun totals(date:String): Pair<Int,Double> {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(calories),0), COALESCE(SUM(protein),0) FROM meals WHERE date=?", arrayOf(date)).use {
            it.moveToFirst(); return it.getInt(0) to it.getDouble(1)
        }
    }
    fun exportJson(): String {
        val root=JSONObject()
        for(t in listOf("workouts","meals","body")) {
            val arr=JSONArray()
            rows(t).forEach { row -> arr.put(JSONObject(row as Map<*,*>)) }
            root.put(t,arr)
        }
        return root.toString(2)
    }
    fun importJson(json:String) {
        val root=JSONObject(json)
        val db=writableDatabase
        db.beginTransaction()
        try {
            for(t in listOf("workouts","meals","body")) {
                if(root.has(t)) {
                    val arr=root.getJSONArray(t)
                    for(i in 0 until arr.length()) {
                        val obj=arr.getJSONObject(i); val v=ContentValues()
                        val cols=when(t) { "workouts"->listOf("date","muscle","exercise","sets","reps","kg","duration"); "meals"->listOf("date","food","calories","protein"); else->listOf("date","weight","waist") }
                        cols.forEach { k -> if(obj.has(k)) { when(k) {
                            "sets","reps","duration","calories" -> v.put(k,obj.optInt(k))
                            "kg","protein","weight","waist" -> v.put(k,obj.optDouble(k))
                            else -> v.put(k,obj.optString(k))
                        } } }
                        db.insert(t,null,v)
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=GymDb(this)
        val prefs=getSharedPreferences("settings", MODE_PRIVATE)
        setContent { GymApp(db, prefs.getBoolean("dark", true), { prefs.edit().putBoolean("dark",it).apply() }) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun GymApp(db:GymDb, initialDark:Boolean, saveDark:(Boolean)->Unit) {
    var dark by remember { mutableStateOf(initialDark) }
    var tab by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val snack= remember { SnackbarHostState() }
    val context= androidx.compose.ui.platform.LocalContext.current
    val backupOut= rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if(uri!=null) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(db.exportJson()) } }
    }
    val backupIn= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { db.importJson(it.readText()) }; refresh++ }
            .onFailure { }
    }
    MaterialTheme(colorScheme=if(dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            topBar={ TopAppBar(title={ Text("My Gym Tracker") }, actions={ IconButton(onClick={dark=!dark;saveDark(dark)}) { Icon(if(dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") } }) },
            bottomBar={ NavigationBar {
                listOf("Workout","Nutrition","Progress","Backup").forEachIndexed { i,s ->
                    NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(when(i){0->Icons.Default.FitnessCenter;1->Icons.Default.Restaurant;2->Icons.Default.ShowChart;else->Icons.Default.Backup},"")},label={Text(s)})
                }
            } },
            snackbarHost={SnackbarHost(snack)}
        ) { pad ->
            key(refresh) {
                when(tab) {
                    0 -> WorkoutScreen(db, Modifier.padding(pad), {refresh++})
                    1 -> NutritionScreen(db, Modifier.padding(pad), {refresh++})
                    2 -> ProgressScreen(db, Modifier.padding(pad))
                    else -> BackupScreen(Modifier.padding(pad), {backupOut.launch("my_gym_tracker_backup.json")}, {backupIn.launch(arrayOf("application/json"))})
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun WorkoutScreen(db:GymDb, modifier:Modifier, changed:()->Unit) {
    var date by remember { mutableStateOf(today()) }; var muscle by remember { mutableStateOf(groups[0]) }
    var exercise by remember { mutableStateOf("") }; var sets by remember { mutableStateOf("3") }; var reps by remember { mutableStateOf("12") }
    var kg by remember { mutableStateOf("") }; var duration by remember { mutableStateOf("") }
    val rows=db.rows("workouts")
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Log workout", style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(date,{date=it},label={Text("Date (YYYY-MM-DD)")}, modifier=Modifier.fillMaxWidth())
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded,{expanded=it}) {
            OutlinedTextField(muscle,{},readOnly=true,label={Text("Muscle group")},modifier=Modifier.menuAnchor().fillMaxWidth(), trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
            ExposedDropdownMenu(expanded,{expanded=false}) { groups.forEach { DropdownMenuItem(text={Text(it)},onClick={muscle=it;expanded=false}) } }
        }
        OutlinedTextField(exercise,{exercise=it},label={Text("Exercise name")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(sets,{sets=it},label={Text("Sets")},modifier=Modifier.weight(1f))
            OutlinedTextField(reps,{reps=it},label={Text("Reps")},modifier=Modifier.weight(1f))
            OutlinedTextField(kg,{kg=it},label={Text("Weight kg")},modifier=Modifier.weight(1f))
        }
        OutlinedTextField(duration,{duration=it},label={Text("Cardio duration (minutes, optional)")},modifier=Modifier.fillMaxWidth())
        if(exercise.isNotBlank()) Text("Previous best for $exercise: ${db.best(exercise)} kg", style=MaterialTheme.typography.bodyMedium)
        Button(onClick={
            if(exercise.isNotBlank()) { db.addWorkout(date,muscle,exercise,sets.toIntOrNull()?:0,reps.toIntOrNull()?:0,kg.toDoubleOrNull()?:0.0,duration.toIntOrNull()?:0); exercise=""; kg=""; duration=""; changed() }
        },modifier=Modifier.fillMaxWidth()) { Text("Save workout entry") }
        Divider()
        Text("Workout history",style=MaterialTheme.typography.titleLarge)
        rows.forEach { r ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text("${r["exercise"]} • ${r["muscle"]}",style=MaterialTheme.typography.titleMedium)
                Text("${r["date"]}  |  ${r["sets"]} sets × ${r["reps"]} reps  |  ${r["kg"]} kg  |  ${r["duration"]} min")
            } }
        }
    }
}

@Composable fun NutritionScreen(db:GymDb, modifier:Modifier, changed:()->Unit) {
    var date by remember { mutableStateOf(today()) }; var food by remember { mutableStateOf("") }
    var calories by remember { mutableStateOf("") }; var protein by remember { mutableStateOf("") }
    val totals=db.totals(today())
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Nutrition tracker",style=MaterialTheme.typography.titleLarge)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("Today's intake",style=MaterialTheme.typography.titleMedium)
            Text("${totals.first} kcal  •  ${"%.1f".format(totals.second)} g protein",style=MaterialTheme.typography.headlineSmall)
        } }
        OutlinedTextField(date,{date=it},label={Text("Date (YYYY-MM-DD)")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(food,{food=it},label={Text("Food / meal description")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(calories,{calories=it},label={Text("Calories kcal")},modifier=Modifier.weight(1f))
            OutlinedTextField(protein,{protein=it},label={Text("Protein g")},modifier=Modifier.weight(1f))
        }
        Button(onClick={ if(food.isNotBlank()) { db.addMeal(date,food,calories.toIntOrNull()?:0,protein.toDoubleOrNull()?:0.0); food=""; calories=""; protein=""; changed() } },modifier=Modifier.fillMaxWidth()) { Text("Save food entry") }
        Divider()
        Text("Food history",style=MaterialTheme.typography.titleLarge)
        db.rows("meals").forEach { r -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text(r["food"]?: "",style=MaterialTheme.typography.titleMedium)
            Text("${r["date"]}  |  ${r["calories"]} kcal  |  ${r["protein"]} g protein")
        } } }
    }
}

@Composable fun ProgressScreen(db:GymDb, modifier:Modifier) {
    var weight by remember { mutableStateOf("") }; var waist by remember { mutableStateOf("") }; var date by remember { mutableStateOf(today()) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Body & progress",style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(date,{date=it},label={Text("Date (YYYY-MM-DD)")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(weight,{weight=it},label={Text("Weight kg")},modifier=Modifier.weight(1f))
            OutlinedTextField(waist,{waist=it},label={Text("Waist cm")},modifier=Modifier.weight(1f))
        }
        Button(onClick={ if(weight.toDoubleOrNull()!=null) { db.addBody(date,weight.toDouble(),waist.toDoubleOrNull()?:0.0); weight=""; waist="" } },modifier=Modifier.fillMaxWidth()) { Text("Save measurement") }
        Divider()
        Text("Body measurement history",style=MaterialTheme.typography.titleLarge)
        db.rows("body").forEach { r -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text("${r["weight"]} kg",style=MaterialTheme.typography.titleMedium)
            Text("${r["date"]}  |  Waist: ${r["waist"]} cm")
        } } }
        Divider()
        Text("Workout statistics",style=MaterialTheme.typography.titleLarge)
        val workouts=db.rows("workouts")
        Text("Total logged exercise entries: ${workouts.size}")
        Text("Workout days: ${workouts.mapNotNull{it["date"]}.distinct().size}")
        val totalMinutes=workouts.sumOf { it["duration"]?.toIntOrNull()?:0 }
        Text("Logged cardio duration: $totalMinutes minutes")
        Text("Exercise personal bests are shown while entering each exercise.")
    }
}

@Composable fun BackupScreen(modifier:Modifier, export:()->Unit, import:()->Unit) {
    Column(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Backup & restore",style=MaterialTheme.typography.titleLarge)
        Text("Your workouts, food diary and body measurements are stored locally on this phone. Export a JSON backup to Google Drive, your phone storage or another safe location.")
        Button(onClick=export,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload,null); Spacer(Modifier.width(8.dp)); Text("Export backup") }
        OutlinedButton(onClick=import,modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload,null); Spacer(Modifier.width(8.dp)); Text("Restore from backup") }
        Text("Important: restoring adds the backup entries to the existing data; it does not erase current records. Keep backup files private.")
        Text("Appearance can be changed using the sun/moon icon in the top bar.")
    }
}
